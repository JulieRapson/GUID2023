﻿Public Class frmBurgers
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub lblConfirmation_Click(sender As Object, e As EventArgs) Handles lblConfirmation.Click

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles lblHeading.Click

    End Sub
End Class
